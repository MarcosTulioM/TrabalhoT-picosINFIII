package universidade;

import View.MenuPrincipal;

/**
 *
 * @author Samuel
 */
public class Universidade {

    public static void main(String[] args) {
        MenuPrincipal menu = new MenuPrincipal();
    }

}
