package Model;

/**
 *
 * @author Marcos
 */
public class Curso {

    private int cod;
    private String nome;
    private String descricao;
    private int SemestreHoras;
    private int nivel;
    private Departamento departamentoResponsavel;

    public Curso(String nome, String descricao, int horasSemestrais, int nivel, Departamento departamentoResponsavel) {
        this.nome = nome;
        this.descricao = descricao;
        this.SemestreHoras = horasSemestrais;
        this.nivel = nivel;
        this.departamentoResponsavel = departamentoResponsavel;
    }

    public Curso(int codigo, String nome, String descricao, int horasSemestrais, int nivel, Departamento departamentoResponsavel) {
        this.cod = codigo;
        this.nome = nome;
        this.descricao = descricao;
        this.SemestreHoras = horasSemestrais;
        this.nivel = nivel;
        this.departamentoResponsavel = departamentoResponsavel;
    }

    public Curso() {
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getSemestreHoras() {
        return SemestreHoras;
    }

    public void setSemestreHoras(int SemestreHoras) {
        this.SemestreHoras = SemestreHoras;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public Departamento getDepartamentoResponsavel() {
        return departamentoResponsavel;
    }

    public void setDepartamentoResponsavel(Departamento departamentoResponsavel) {
        this.departamentoResponsavel = departamentoResponsavel;
    }

    @Override
    public String toString() {
        return "Curso{" + "codigo=" + cod + "\n"
                + "nome=" + nome + "\n"
                + "descricao=" + descricao + "\n"
                + "horasSemestrais=" + SemestreHoras + "\n"
                + "nivel=" + nivel + "\n"
                + "departamentoResponsavel=" + departamentoResponsavel + '}';
    }

}
