
package Model;

import java.util.Date;

/**
 *
 * @author Marcos
 */
public class Aluno {

    private int numMatricula;
    private String nome;
    private String cpf;
    private String endereco;
    private String telefone;
    private Date nascData;
    private char sexo;
    private String turma;
    private Departamento dpPrincipal;
    private String programa;

    public Aluno(int numeroMatricula, String nome, String cpf, String endereco, String telefone, Date dataNascimento, char sexo, String turma, Departamento departamentoPrincipal, String programa) {
        this.numMatricula = numeroMatricula;
        this.nome = nome;
        this.cpf = cpf;
        this.endereco = endereco;
        this.telefone = telefone;
        this.nascData = dataNascimento;
        this.sexo = sexo;
        this.turma = turma;
        this.dpPrincipal = departamentoPrincipal;
        this.programa = programa;
    }

    public Aluno(String nome, String cpf, String endereco, String telefone, Date dataNascimento, char sexo, String turma, Departamento departamentoPrincipal, String programa) {
        this.nome = nome;
        this.cpf = cpf;
        this.endereco = endereco;
        this.telefone = telefone;
        this.nascData = dataNascimento;
        this.sexo = sexo;
        this.turma = turma;
        this.dpPrincipal = departamentoPrincipal;
        this.programa = programa;
    }

    public Aluno() {
    }

    public int getNumMatricula() {
        return numMatricula;
    }

    public void setNumMatricula(int numMatricula) {
        this.numMatricula = numMatricula;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public Date getNascData() {
        return nascData;
    }

    public void setNascData(Date nascData) {
        this.nascData = nascData;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public String getTurma() {
        return turma;
    }

    public void setTurma(String turma) {
        this.turma = turma;
    }

    public Departamento getDpPrincipal() {
        return dpPrincipal;
    }

    public void setDpPrincipal(Departamento dpPrincipal) {
        this.dpPrincipal = dpPrincipal;
    }

    public String getPrograma() {
        return programa;
    }

    public void setPrograma(String programa) {
        this.programa = programa;
    }

    @Override
    public String toString() {
        return "numeroMatricula = " + numMatricula
                + "\nnome = " + nome
                + "\ncpf = " + cpf
                + "\nendereco = " + endereco
                + "\ntelefone = " + telefone
                + "\ndataNascimento = " + nascData
                + "\nsexo = " + sexo
                + "\nturma = " + turma
                + "\ndepartamentoPrincipal = " + dpPrincipal
                + "\nprograma = " + programa;
    }

}
