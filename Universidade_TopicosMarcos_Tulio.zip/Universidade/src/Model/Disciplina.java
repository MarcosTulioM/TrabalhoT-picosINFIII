package Model;

/**
 *
 * @author Marcos
 */
public class Disciplina {

    private int cod;
    private String profNome;
    private String semestre;
    private int ano;
    private Curso curso;

    public Disciplina() {
    }

    public Disciplina(String nomeProfessor, Curso curso) {
        this.profNome = nomeProfessor;
        this.curso = curso;
    }

    public Disciplina(String nomeProfessor, String semestre, int ano, Curso curso) {
        this.profNome = nomeProfessor;
        this.semestre = semestre;
        this.ano = ano;
        this.curso = curso;
    }

    public Disciplina(int codigo, String nomeProfessor, String semestre, int ano, Curso curso) {
        this.cod = codigo;
        this.profNome = nomeProfessor;
        this.semestre = semestre;
        this.ano = ano;
        this.curso = curso;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getProfNome() {
        return profNome;
    }

    public void setProfNome(String profNome) {
        this.profNome = profNome;
    }

    public String getSemestre() {
        return semestre;
    }

    public void setSemestre(String semestre) {
        this.semestre = semestre;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    @Override
    public String toString() {
        return "Disciplina{" + "codigo=" + cod + ", nomeProfessor=" + profNome + ", semestre=" + semestre + ", ano=" + ano + ", curso=" + curso + '}';
    }

}
