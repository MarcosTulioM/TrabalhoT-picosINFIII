package Model;

/**
 *
 * @author Marcos
 */
public class Departamento {

    private int cod;
    private String nome;
    private int numSala;
    private String telSala;

    public Departamento() {
    }

    public Departamento(String nome, int numeroSala, String telefoneSala) {
        this.nome = nome;
        this.numSala = numeroSala;
        this.telSala = telefoneSala;
    }

    public Departamento(int codigo, String nome, int numeroSala, String telefoneSala) {
        this.cod = codigo;
        this.nome = nome;
        this.numSala = numeroSala;
        this.telSala = telefoneSala;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNumeroSala() {
        return numSala;
    }

    public void setNumeroSala(int numeroSala) {
        this.numSala = numeroSala;
    }

    public String getTelefoneSala() {
        return telSala;
    }

    public void setTelefoneSala(String telefoneSala) {
        this.telSala = telefoneSala;
    }

    @Override
    public String toString() {
        return "codigo = " + cod + "\n"
                + "nome = " + nome + "\n"
                + "numeroSala = " + numSala + "\n"
                + "telefoneSala = " + telSala + '}';
    }
}
